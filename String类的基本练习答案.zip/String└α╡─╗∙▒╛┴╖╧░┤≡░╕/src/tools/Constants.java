package tools;

public final class Constants {
	private Constants(){}
	public static String str1="!@#$%^&*($%^()$*()#$()#()@#$(#$#$%^&*()_)(*&^%$_@#$%^&*()(*&^%$#@#$%^&*(OKJNBVDE%^&UJ)";
	public static String str2="!@#$%^&*($%^()$*()#$()#()@#$(#$#$%^&*()_)(*&^%$-@#$%^&*()(*&^%$#@#$%^&*(OKJNBVDE%^&UJ)";
}
